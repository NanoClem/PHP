<?php
/* Smarty version 3.1.30, created on 2018-01-07 20:10:17
  from "D:\Users\Clement\Progs_files\uWampServer\www\PHP\MaiteRecettes\application\views\layout\layout_pied.inc.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5a527ea99f6845_28532846',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '25574d169fffa64267992bd0f3739732e17f0589' => 
    array (
      0 => 'D:\\Users\\Clement\\Progs_files\\uWampServer\\www\\PHP\\MaiteRecettes\\application\\views\\layout\\layout_pied.inc.tpl',
      1 => 1511818551,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5a527ea99f6845_28532846 (Smarty_Internal_Template $_smarty_tpl) {
?>
<p>&copy; 2017 Brand_Irlepe.com</p>
<?php }
}
