<?php
/* Smarty version 3.1.30, created on 2018-01-07 18:04:55
  from "D:\Users\Clement\Progs_files\uWampServer\www\PHP\CodeIgniter-3.1.6\application\views\layout\layout_pied.inc.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5a526147b105b0_43933271',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'de0ea4822e93121a7b784a6239e0a5e4538be0d9' => 
    array (
      0 => 'D:\\Users\\Clement\\Progs_files\\uWampServer\\www\\PHP\\CodeIgniter-3.1.6\\application\\views\\layout\\layout_pied.inc.tpl',
      1 => 1511818551,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5a526147b105b0_43933271 (Smarty_Internal_Template $_smarty_tpl) {
?>
<p>&copy; 2017 Brand_Irlepe.com</p>
<?php }
}
