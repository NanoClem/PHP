<?php
/* Smarty version 3.1.30, created on 2018-01-07 20:10:17
  from "D:\Users\Clement\Progs_files\uWampServer\www\PHP\MaiteRecettes\application\views\layout\layout_entete.inc.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5a527ea990f276_21419579',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b05b85ef60442caaacf80773c872ed1ca7438f00' => 
    array (
      0 => 'D:\\Users\\Clement\\Progs_files\\uWampServer\\www\\PHP\\MaiteRecettes\\application\\views\\layout\\layout_entete.inc.tpl',
      1 => 1515092964,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5a527ea990f276_21419579 (Smarty_Internal_Template $_smarty_tpl) {
?>
<img src="asset/images/header.png" align="left" width="80" height="110">
<h1>La cuisine de Maïté</h1>
<h3>Moulte moules</h3> <br />
<?php }
}
