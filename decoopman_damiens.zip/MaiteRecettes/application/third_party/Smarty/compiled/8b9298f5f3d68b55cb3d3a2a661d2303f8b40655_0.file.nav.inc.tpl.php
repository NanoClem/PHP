<?php
/* Smarty version 3.1.30, created on 2018-01-07 18:04:55
  from "D:\Users\Clement\Progs_files\uWampServer\www\PHP\CodeIgniter-3.1.6\application\views\nav\nav.inc.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5a526147ab6ab5_12273586',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8b9298f5f3d68b55cb3d3a2a661d2303f8b40655' => 
    array (
      0 => 'D:\\Users\\Clement\\Progs_files\\uWampServer\\www\\PHP\\CodeIgniter-3.1.6\\application\\views\\nav\\nav.inc.tpl',
      1 => 1515336293,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5a526147ab6ab5_12273586 (Smarty_Internal_Template $_smarty_tpl) {
?>

  <a href="<?php echo base_url();?>
">Accueil</a>
  <a href="<?php echo base_url('/recette');?>
">les Recettes</a>
  <a href="<?php echo base_url('/membre/connexion');?>
">Espace perso</a>
<?php }
}
