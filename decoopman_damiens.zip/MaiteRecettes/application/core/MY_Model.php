<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


  class MY_Model extends CI_Model
  {
    public function __construct()
    {
      parent:__construct();
    }

    /**
     * Récupère des données dans la BDD
     * en fonction de l'id passé en paramètre
     */
     public function find($id)
     {

     }

     /**
      * Retourne une liste de résultats
      */
     public function get_all()
     {

     }
  }
?>
